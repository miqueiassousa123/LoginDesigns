/**************OBJECTS************

students = [];

function student(firstName, lastName, age) {
    this.firstName = firstName;
    this.lastName = lastName;
    this.age = age;

}
students.push(new student(" Luige", " Mario", 5));
students.push(new student("Mick", "Sousa", 33));
console.log(students);

//////////////////////////////////////////////////////////
var cars = [];


function Car (Model, year, colour, price){
    this.Model = Model;
    this.year = year;
    this.colour = colour;
    this.price = price;
    this.Message = function(){
        return " Hello !! your car is a: " + this.Model + " Year:"+ this.year + " Colour "+ this.colour +
            " and the price is " + this.price;
    }  
}

cars.push(new Car("BMW", 2016, "black", 19802));
cars.push( new Car (" Mercedes", 2020 ," Red", 7500));

console.log(cars);

for (var index = 0; index < cars.length; index++){ 
    var Car = cars[index];
    console.log(Car.Message());

}
*/


    
    


/**************FUNCTIONS*********************
var balance = 1900;
var total;


var purchase = function (price, tax) {
    total = price + tax;

    if (total <= balance) {
        balance -= total;
        console.log(" Your purchase was : " + total + " Your new balance is " + balance);

    } else {
        console.log(" isufficient Funds");

    }
    saveTransactions = [];
    saveTransactions.push(total);
    console.log(saveTransactions);
}
purchase(10, 5);
purchase(20, 5);
purchase(30, 5);
purchase(40, 5);/ 



/********************* FOR LOOPS*************************



var fruits = ["Banana", "Orange", "Apple", "Mango", "Melon", "Peach", "Pear"];

for ( fruit = 0; fruit < fruits.length; fruit++){
    
    console.log(fruits[fruit]);
}

*/


/*RETRIEVING DATA FROM ARRAYS AND DELETING DATA FROM ARRAYS 

var salary = [1500, 2700, 1500,950,350];

var checkSalaries =[];
checkSalaries.push(salary[0]);
checkSalaries.push(salary[1]);

var index = checkSalaries.indexOf(1500);


if(index >-1){
    checkSalaries.splice(index,1);
    
    
}
console.log(checkSalaries);


****************************************************************************
var names = ["marcus", "luis", "jose", "antonio", "joao", "paulo"];

var getNames = [];
getNames.push(names[5]);
getNames.push(names[0]);

console.log(getNames);
var index = getNames.indexOf("paulo");

if (index > -1) {
    getNames.splice(index, 1);

}

console.log(getNames);
/ 


/*var name = "Miqueias";
var age = 23;
var shootingScore = 25.5;
var imageProfile = "http:/"

var message = "My name is " + name + " and I am "+ age + " years old! and my score is " + shootingScore;
console.log(message); 
*/
/*var name = " Miqueias";
var lastName = " Sousa dos Santos";
var dataOfBirth = " 05-09-1986";
var age = 33;

var greattingMessage = " Welcome " + name + " "  + lastName + " Happy " + age + "rd birthday " + "you were born on the " + dataOfBirth;
console.log(greattingMessage);*/
/*var myAccount = 100;
var shoes = 600;
var cupon = 500;
if( shoes <= myAccount){
    myAccount -= shoes;
    console.log(" You bought new shoes");
    console.log(" new balane" + myAccount);

}else if( shoes <= cupon + myAccount){ 
    
  console.log(" You bought new shoes");
    myAccount += cupon;
    myAccount -= shoes;
    console.log(" new balane" + myAccount);  
}else(

console.log(" issuficent balance")
)
*/



/*var price = 195.00;
var priceUP = 204.00;
var priceDown = 190.00;
var diffUp = priceUP - price;
var diffDw = price- priceDown;
var newvalue= 299.75;
console.log(diffUp);
console.log(diffDw);

if(diffUp <diffDw){
    console.log(" The discount is higther than the price Up");
} else if(newvalue !== 0 && newvalue >=  200){
             console.log("discount to hight")
         }else if(diffUp > diffDw){
         console.log("The price up is hight than the descount");
         }else if (diffUp==diffDw){
             console.log("There is no difference between up and down values ")
         }*/
